const serverless = require("serverless-http");
var express = require("express");
const fs = require("fs");
const path = require('path');
const Joi = require("joi");
const multer = require("multer");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const {
  authenticateToken,
  registerEmployee,
  loginEmployee,
} = require("./auth");
const { refreshAccessToken, logoutEmployee } = require("./auth");
const db = require("./db");
const app = express();

// Middleware to parse JSON bodies
app.use(express.json());

// Ensure the 'uploads' directory exists
if (!fs.existsSync("uploads")) {
  fs.mkdirSync("uploads");
}

// Set up storage configuration for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/"); // Directory to save uploaded files
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const filename = Date.now() + ext; // Filename with timestamp to avoid conflicts
    cb(null, filename);
  },
});

// File filter function to validate file types
const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    "image/jpeg",
    "image/jpg",
    "image/png",
    "application/pdf",
  ];
  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(
      new Error(
        "Invalid file type. Only JPEG, JPG, PNG, and PDF files are allowed."
      ),
      false
    );
  }
};

// Multer configuration with limits and file filter
const upload = multer({
  storage: storage,
  limits: { fileSize: 2 * 1024 * 1024 }, // Limit file size to 2MB
  fileFilter: fileFilter,
});

// Joi schema for validating employee data
const employeeSchema = Joi.object({
  first_name: Joi.string().trim(),
  last_name: Joi.string().trim(),
  email: Joi.string().email().trim().required(),
  phone_number: Joi.string().trim().optional(),
  date_of_birth: Joi.date().iso().optional(),
  gender: Joi.string().valid("male", "female", "other").optional(),
  address: Joi.string().trim().optional(),
  city: Joi.string().trim().optional(),
  state: Joi.string().trim().optional(),
  country: Joi.string().trim().optional(),
  zip_code: Joi.string().trim().optional(),
  department: Joi.string().trim().optional(),
  job_title: Joi.string().trim().optional(),
  salary: Joi.number().min(0).optional(),
  hire_date: Joi.date().iso().optional(),
  profile_picture: Joi.string().optional(),
  username: Joi.string().trim().required(),
  password: Joi.string().trim().required(),
});

// Joi schema for partially updating employee data
const employeePatchSchema = Joi.object({
  first_name: Joi.string().trim().optional(),
  last_name: Joi.string().trim().optional(),
  email: Joi.string().email().trim().optional(),
  phone_number: Joi.string().trim().optional(),
  date_of_birth: Joi.date().iso().optional(),
  gender: Joi.string().valid("male", "female", "other").optional(),
  address: Joi.string().trim().optional(),
  city: Joi.string().trim().optional(),
  state: Joi.string().trim().optional(),
  country: Joi.string().trim().optional(),
  zip_code: Joi.string().trim().optional(),
  department: Joi.string().trim().optional(),
  job_title: Joi.string().trim().optional(),
  salary: Joi.number().min(0).optional(),
  hire_date: Joi.date().iso().optional(),
  profile_picture: Joi.string().optional(),
  username: Joi.string().trim().required(),
  password: Joi.string().trim().required(),
});

// Middleware to validate request data using Joi
const validateEmployee = (req, res, next) => {
  const { error } = employeeSchema.validate(req.body, { abortEarly: false });
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((err) => err.message) });
  }
  next();
};

const validateEmployeePatch = (req, res, next) => {
  const { error } = employeePatchSchema.validate(req.body, {
    abortEarly: false,
  });
  if (error) {
    return res
      .status(400)
      .json({ errors: error.details.map((err) => err.message) });
  }
  next();
};

// Route to register a new user
app.post("/register", (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res
      .status(400)
      .json({ message: "Username and password are required" });
  }
  registerEmployee(username, password, (err) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.status(201).json({ message: "User registered successfully" });
  });
});

// Route to login and get a JWT token
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res
      .status(400)
      .json({ message: "Username and password are required" });
  }
  loginEmployee(username, password, (err, token) => {
    if (err) {
      return res.status(401).json({ message: "Invalid username or password" });
    }
    res.json({ token });
  });
});

// Route to refresh access token using refresh token
app.post("/refresh-token", refreshAccessToken);

// Route to log out and invalidate the refresh token
app.post("/logout", logoutEmployee);

// Route to handle adding a new employee with file upload
app.post(
  "/employees",
  upload.single("profile_picture"),
  authenticateToken,
  validateEmployee,
  (req, res) => {
    const {
      first_name,
      last_name,
      email,
      phone_number,
      date_of_birth,
      gender,
      address,
      city,
      state,
      country,
      zip_code,
      department,
      job_title,
      salary,
      hire_date,
    } = req.body;

    const profilePicture = req.file ? req.file.filename : null;

    const sql = `INSERT INTO Emp 
      (first_name, last_name, email, phone_number, date_of_birth, gender,
       address, city, state, country, zip_code, department, job_title, salary, hire_date, profile_picture) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

    db.query(
      sql,
      [
        first_name,
        last_name,
        email,
        phone_number,
        date_of_birth,
        gender,
        address,
        city,
        state,
        country,
        zip_code,
        department,
        job_title,
        salary,
        hire_date,
        profilePicture,
      ],
      (err, result) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        res.json({
          id: result.insertId,
          ...req.body,
          profile_picture: profilePicture,
        });
      }
    );
  }
);

// Route to handle updating an employee with file upload
app.put(
  "/employees/:id",
  upload.single("profile_picture"),
  authenticateToken,
  validateEmployee,
  (req, res) => {
    const { id } = req.params;
    const {
      first_name,
      last_name,
      email,
      phone_number,
      date_of_birth,
      gender,
      address,
      city,
      state,
      country,
      zip_code,
      department,
      job_title,
      salary,
      hire_date,
    } = req.body;

    const profilePicture = req.file ? req.file.filename : null;

    const sql = `UPDATE Emp SET 
      first_name = ?, last_name = ?, email = ?, phone_number = ?, date_of_birth = ?, gender = ?,
      address = ?, city = ?, state = ?, country = ?, zip_code = ?, department = ?, job_title = ?, salary = ?, hire_date = ?,
      profile_picture = COALESCE(?, profile_picture) 
      WHERE id = ?`;

    db.query(
      sql,
      [
        first_name,
        last_name,
        email,
        phone_number,
        date_of_birth,
        gender,
        address,
        city,
        state,
        country,
        zip_code,
        department,
        job_title,
        salary,
        hire_date,
        profilePicture,
        id,
      ],
      (err, result) => {
        if (err) {
          return res.status(500).json({ error: err.message });
        }
        if (result.affectedRows === 0) {
          return res.status(404).json({ message: "Employee not found" });
        }
        res.json({ message: "Employee updated successfully" });
      }
    );
  }
);

// Route to handle partially updating an employee's data
app.patch(
  "/employees/:id",
  upload.single("profile_picture"),
  authenticateToken,
  validateEmployeePatch,
  (req, res) => {
    const { id } = req.params;
    const updates = req.body;

    // Ensure updates is an object
    if (!updates || typeof updates !== 'object' || Array.isArray(updates)) {
      return res.status(400).json({ message: "Invalid data format" });
    }

    let sql = "UPDATE Emp SET ";
    const updateValues = [];

    // Add fields from req.body to the update query
    for (const key in updates) {
      if (Object.prototype.hasOwnProperty.call(updates, key)) {
        sql += `${key} = ?, `;
        updateValues.push(updates[key]);
      }
    }

    // If a profile picture is uploaded, add it to the update query
    if (req.file) {
      sql += `profile_picture = ?, `;
      updateValues.push(req.file.filename);
    }

    // If there are no fields to update, return an error
    if (updateValues.length === 0) {
      return res.status(400).json({ message: "No valid fields to update" });
    }

    // Remove the trailing comma and space
    sql = sql.slice(0, -2);
    sql += " WHERE id = ?";
    updateValues.push(id);

    // Execute the update query
    db.query(sql, updateValues, (err, result) => {
      if (err) {
        return res.status(500).json({ error: err.message });
      }

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Employee not found" });
      }
      res.json({ message: "Employee updated successfully" });
    });
  }
);

// Route to delete an employee by ID
app.delete("/employees/:id", authenticateToken, (req, res) => {
  const { id } = req.params;

  const sql = "DELETE FROM Emp WHERE id = ?";

  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json({ message: "Employee deleted successfully" });
  });
});

// Route to fetch employee details by ID
app.get("/employees/:id", authenticateToken, (req, res) => {
  const { id } = req.params;

  const sql = "SELECT * FROM Emp WHERE id = ?";

  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (result.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json(result[0]);
  });
});

// Route to fetch employee details by ID
app.get("/employees", (req, res) => {
  const { id } = req.params;

  const sql = "SELECT * FROM Emp";

  db.query(sql, [id], (err, result) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    if (result.length === 0) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json(result[0]);
  });
});

// Export handler for serverless
module.exports = app;
